from PID_Controller import PID

class CarController:
    speed_pid = PID()
    speed_pid.kp = 1.0 # 1.0 for pure P seemds to work well
    
    steer_pid = PID()
    steer_pid.kp = 0.5
    
    crosstrack_pid = PID()
    crosstrack_pid.kp = 0.05
    crosstrack_pid.kd = 1.0