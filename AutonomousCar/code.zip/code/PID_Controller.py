class PID:
    kp = 0.0
    ki = 0.0
    kd = 0.0
    
    error_sum = 0.0
    max_error_sum = 0.0
    last_error = 0.0
    initialized = False
    
    ts = []
    u_ps = []
    u_is = []
    u_ds = []
    rise_time = 0.0 # what did it take to get to 70% of desired value
    overshoot = 0.0 # maximum % over
    settling_time = 0.0 # how long did it take to get and stay within 2%
    
    def __init__(self):
        self.error_sum = 0.0
        self.last_error = 0.0
        self.initialized = False
        
    def tic(self, s, s_d, log_components = False):
        e = s_d - s
        p = self.kp * e
        
        d = 0.0
        if self.initialized:
            d = self.kd * (e - self.last_error)
            self.last_error = e
        else:
            self.initialized = True
            self.last_error = e

        self.error_sum += e
        self.error_sum = self.clamp(self.error_sum, -self.max_error_sum, self.max_error_sum)
        i = self.ki * self.error_sum
        
        if log_components:
            self.u_ps.append(p)
            self.u_is.append(i)
            self.u_ds.append(d)
            
        return p + i + d
    
    def clamp(self, x, x_min, x_max):
        '''This ensures  x_min <= x <= x_max'''
        return min(x_max, max(x_min, x))
    
    def extract_performance(self, ts, ss, s_d):
        # get pid inputs
        rise_time = 0.0
        rise_set = False
        settling_time = 0.0
        overshoot = 0.0
        rise_set = False
        s_range = s_d - ss[0]
        for t, s in zip(ts, ss):
            # get rise time
            if not rise_set and s > ss[0] + 0.7 * s_range:
                rise_time = t
                rise_set = True
            
            # get overshoot
            if (s - s_d)/s_range > overshoot:
                overshoot = (s-s_d) / s_range
            
            # get settling time
            if abs(s_d - s)/s_range > 0.02:
                settling_time = t

        return [rise_time, overshoot, settling_time]