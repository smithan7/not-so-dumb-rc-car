class CarParam:
    max_steering_angle = 0.5435 # radians
    max_steering_rate = 0.3294 # radians / second
    max_speed = 62.6 # m/s = #140 mph
    characteristic_velocity = 20.0 # m/s - drives side slip
    steer_damping = 1.0 / 0.3 # seconds
    accel_damping = 1.0 / 0.3 # seconds
    max_braking_accel = -6.0 # m/s^2
    max_forward_accel = 1.8 # m/s^2
    max_centripetal_accel = 1.2*9.81 # m/s^2
    length = 28 * 0.0254 # 2.885 # meters    
    
    mass = 8.0 # kg
    c_y = 145.0 # lateral tire stiffness
    a = length / 2.0 # center of mass to front wheels
    b = length / 2.0 # center of mass to rear wheels
    
    def __init__(self):
        pass